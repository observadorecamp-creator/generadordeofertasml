# 🔥 Ofertas ML API

API Backend con Next.js + Workflow para Ofertas ML Hub

## 🚀 Instalación

```bash
npm install
```

## 🧪 Desarrollo

```bash
npm run dev
```

## 📦 Build

```bash
npm run build
```

## 🌐 Deploy en Vercel

1. Sube el código a GitHub
2. Conecta el repositorio en Vercel
3. Deploy automático

## 📡 Endpoints

- `POST /api/products/verify` - Verificar enlaces ML
- `POST /api/offers/schedule` - Programar ofertas
- `GET /api/health` - Health check

## 👨‍💻 Autor

Hugo Cal - [@hugocal13](https://t.me/hugocal13)
