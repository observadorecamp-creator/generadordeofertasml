import { sleep } from "workflow";

export async function verifyMLLink(productId: string, mlUrl: string) {
  "use workflow";
  
  console.log(`🔍 Iniciando verificación para producto ${productId}`);
  
  for (let day = 0; day < 30; day++) {
    const isValid = await checkMLLink(mlUrl);
    
    if (!isValid) {
      await notifyBrokenLink(productId, mlUrl);
      console.log(`❌ Link roto detectado: ${productId}`);
      break;
    }
    
    console.log(`✅ Día ${day + 1}: Link válido para ${productId}`);
    await sleep("24h");
  }
  
  console.log(`🏁 Verificación completada para ${productId}`);
}

async function checkMLLink(url: string) {
  "use step";
  
  try {
    const response = await fetch(url, { 
      method: 'HEAD',
      redirect: 'follow'
    });
    
    return response.ok && response.status !== 404;
  } catch (error) {
    console.error('Error verificando link:', error);
    return false;
  }
}

async function notifyBrokenLink(productId: string, url: string) {
  "use step";
  
  const message = `⚠️ ALERTA: Link roto detectado\nProducto: ${productId}\nURL: ${url}`;
  console.log(message);
}