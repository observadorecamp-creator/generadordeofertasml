import { sleep } from "workflow";

export async function scheduleOfferExpiration(
  offerId: string, 
  expiresInHours: number
) {
  "use workflow";
  
  console.log(`⏰ Oferta ${offerId} programada para expirar en ${expiresInHours} horas`);
  
  if (expiresInHours > 1) {
    await sleep(`${expiresInHours - 1}h`);
    await sendExpirationWarning(offerId);
  }
  
  await sleep("1h");
  await expireOffer(offerId);
  
  console.log(`✅ Workflow completado para oferta ${offerId}`);
}

async function sendExpirationWarning(offerId: string) {
  "use step";
  
  const message = `⏰ La oferta ${offerId} expirará en 1 hora`;
  console.log(message);
}

async function expireOffer(offerId: string) {
  "use step";
  
  const message = `❌ La oferta ${offerId} ha expirado`;
  console.log(message);
}