export const metadata = {
  title: 'Ofertas ML API',
  description: 'API Backend para Ofertas ML Hub',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="es">
      <body>{children}</body>
    </html>
  )
}