export default function Home() {
  return (
    <main style={{ padding: '2rem', fontFamily: 'system-ui' }}>
      <h1>🔥 Ofertas ML API</h1>
      <p>Backend con Workflow para Ofertas ML Hub</p>
      
      <h2>Endpoints disponibles:</h2>
      <ul>
        <li><code>POST /api/products/verify</code> - Verificar enlaces de productos</li>
        <li><code>POST /api/offers/schedule</code> - Programar expiración de ofertas</li>
        <li><code>GET /api/health</code> - Estado del servidor</li>
      </ul>

      <h2>Ejemplo de uso:</h2>
      <pre style={{ background: '#f4f4f4', padding: '1rem', borderRadius: '8px' }}>
{`fetch('https://tu-api.vercel.app/api/products/verify', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    productId: '123',
    mlUrl: 'https://mercadolibre.com/...'
  })
})`}
      </pre>
    </main>
  )
}