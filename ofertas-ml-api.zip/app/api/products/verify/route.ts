import { start } from 'workflow/api';
import { verifyMLLink } from '@/workflows/verify-ml-links';
import { NextResponse } from 'next/server';

export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    },
  });
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { productId, mlUrl } = body;
    
    if (!productId || !mlUrl) {
      return NextResponse.json(
        { error: 'Se requieren productId y mlUrl' },
        { status: 400 }
      );
    }
    
    if (!mlUrl.includes('mercadolibre.com') && !mlUrl.includes('mercadolibre.mx')) {
      return NextResponse.json(
        { error: 'La URL debe ser de Mercado Libre' },
        { status: 400 }
      );
    }
    
    await start(verifyMLLink, [productId, mlUrl]);
    
    return NextResponse.json({ 
      success: true,
      message: 'Verificación programada exitosamente',
      productId,
      mlUrl
    });
    
  } catch (error) {
    console.error('Error en /api/products/verify:', error);
    return NextResponse.json(
      { error: 'Error al programar verificación' },
      { status: 500 }
    );
  }
}