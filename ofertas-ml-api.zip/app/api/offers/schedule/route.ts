import { start } from 'workflow/api';
import { scheduleOfferExpiration } from '@/workflows/scheduled-offers';
import { NextResponse } from 'next/server';

export async function OPTIONS() {
  return new NextResponse(null, {
    status: 200,
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'POST, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type',
    },
  });
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { offerId, expiresInHours } = body;
    
    if (!offerId || !expiresInHours) {
      return NextResponse.json(
        { error: 'Se requieren offerId y expiresInHours' },
        { status: 400 }
      );
    }
    
    if (expiresInHours < 1 || expiresInHours > 720) {
      return NextResponse.json(
        { error: 'expiresInHours debe estar entre 1 y 720 (30 días)' },
        { status: 400 }
      );
    }
    
    await start(scheduleOfferExpiration, [offerId, Number(expiresInHours)]);
    
    return NextResponse.json({ 
      success: true,
      message: 'Oferta programada exitosamente',
      offerId,
      expiresInHours,
      expiresAt: new Date(Date.now() + expiresInHours * 60 * 60 * 1000).toISOString()
    });
    
  } catch (error) {
    console.error('Error en /api/offers/schedule:', error);
    return NextResponse.json(
      { error: 'Error al programar oferta' },
      { status: 500 }
    );
  }
}