import { NextResponse } from 'next/server';

export async function GET() {
  return NextResponse.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    service: 'Ofertas ML API',
    version: '1.0.0',
    endpoints: {
      'POST /api/products/verify': 'Verificar enlaces de productos ML',
      'POST /api/offers/schedule': 'Programar expiración de ofertas',
      'GET /api/health': 'Estado del servidor'
    }
  });
}